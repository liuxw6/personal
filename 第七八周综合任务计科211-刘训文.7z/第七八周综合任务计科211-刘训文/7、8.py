import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from tqdm.notebook import trange

import torch
import torch.nn as nn
import torch.optim as optim
import torch.autograd as autograd
import torch.utils.data as data

import torchvision
import torchvision.datasets as datasets
import torchvision.transforms as transforms

import sklearn.metrics as metrics
from sklearn.model_selection import train_test_split
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()

        self.features = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        for child in self.features.children():
            if isinstance(child, nn.Conv2d):
                n = child.kernel_size[0] * child.kernel_size[1] * child.out_channels
                child.weight.data.normal_(0, np.sqrt(2.0 / n, dtype=float))
            elif isinstance(child, nn.BatchNorm2d):
                child.weight.data.fill_(1)
                child.bias.data.zero_()

        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(256 * 7 * 7, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(1024, 10)
        )

    for child in self.classifier.children():
            if isinstance(child, nn.Linear):
                nn.init.xavier_uniform_(child.weight)
            elif isinstance(child, nn.BatchNorm1d):
                child.weight.data.fill_(1)
                child.bias.data.zero_()

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)

        return self.classifier(x)
if torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")
batch_size = 64
epochs = 25

model = CNN().to(device)

optimizer = optim.Adam(model.parameters(), lr=3.5e-3)
criterion = nn.CrossEntropyLoss()
scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.075)
train_csv = pd.read_csv("../input/digit-recognizer/train.csv", dtype=np.uint8)

train_labels = train_csv.label.values
train_images = train_csv.loc[:, train_csv.columns != "label"].values / 255.0

images_train, images_eval, labels_train, labels_eval = train_test_split(train_images, train_labels, test_size = 0.2)

images_train = torch.from_numpy(images_train).type(torch.FloatTensor)
labels_train = torch.from_numpy(labels_train).type(torch.LongTensor)

images_eval = torch.from_numpy(images_eval).type(torch.FloatTensor)
labels_eval = torch.from_numpy(labels_eval).type(torch.LongTensor)

train_dataset = torch.utils.data.TensorDataset(images_train, labels_train)
eval_dataset = torch.utils.data.TensorDataset(images_eval, labels_eval)

# Load test data
test_csv = pd.read_csv("../input/digit-recognizer/test.csv")
test_images = train_csv.values
test_images = torch.from_numpy(test_images)
test_data = torch.utils.data.TensorDataset(test_images)
test = torch.utils.data.DataLoader(test_data, batch_size = batch_size, shuffle = True)
temp = [train_dataset[index][1] for index in range(len(train_dataset))]
values, count = np.unique(temp, return_counts=True)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5.2, 4.8), dpi=100)

fig.tight_layout()

temp = [train_dataset[index][1] for index in range(len(train_dataset))]
values, count = np.unique(temp, return_counts=True)

ax1.bar(values, count)
ax1.set_xlabel("Class")
ax1.set_ylabel("Count")
ax1.set_xticks(values)
ax1.set_title("Class distribution in train data")

temp = [eval_dataset[index][1] for index in range(len(eval_dataset))]
values, count = np.unique(temp, return_counts=True)

ax2.bar(values, count)
ax2.set_xlabel("Class")
ax2.set_ylabel("Count")
ax2.set_xticks(values)
ax2.set_title("Class distribution in evaluation data")

fig.subplots_adjust(hspace=0.5)

fig.show()
temp = [train_dataset[index][1] for index in range(len(train_dataset))]
values, count = np.unique(temp, return_counts=True)

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(5.2, 4.8), dpi=100)

fig.tight_layout()

temp = [train_dataset[index][1] for index in range(len(train_dataset))]
values, count = np.unique(temp, return_counts=True)

ax1.bar(values, count)
ax1.set_xlabel("Class")
ax1.set_ylabel("Count")
ax1.set_xticks(values)
ax1.set_title("Class distribution in train data")

temp = [eval_dataset[index][1] for index in range(len(eval_dataset))]
values, count = np.unique(temp, return_counts=True)

ax2.bar(values, count)
ax2.set_xlabel("Class")
ax2.set_ylabel("Count")
ax2.set_xticks(values)
ax2.set_title("Class distribution in evaluation data")

fig.subplots_adjust(hspace=0.5)

fig.show()
def train(loader: data.DataLoader):
    in_train_correct = 0
    in_train_loss = 0
    in_train_total = 0

    with torch.enable_grad():
        model.train()
        for image, label in loader:
            image = autograd.Variable(image.view(-1, 1, 28, 28)).to(device)
            label = autograd.Variable(label).to(device)

            optimizer.zero_grad()

            output = model(image)
            loss = criterion(output, label)
            loss.backward()

            optimizer.step()

            in_train_loss += loss.item()
            in_train_total += len(label)

            _, prediction = output.data.max(1, keepdim=False)
            in_train_correct += int((prediction == label).sum())

    return in_train_correct, in_train_loss, in_train_total

def evaluate(loader: data.DataLoader):
    in_eval_correct = 0
    in_eval_loss = 0
    in_eval_total = 0

    with torch.no_grad():
        model.eval()
        for image, label in loader:
            image = autograd.Variable(image.view(-1, 1, 28, 28)).to(device)
            label = autograd.Variable(label).to(device)

            output = model(image)
            in_eval_loss += criterion(output, label).item()
            in_eval_total += len(label)

            _, prediction = output.data.max(1, keepdim=False)
            in_eval_correct += int((prediction == label).sum())

    return in_eval_correct, in_eval_loss, in_eval_total

train_loss = []
train_accuracy = []
eval_loss = []
eval_accuracy = []

for index in trange(epochs, desc="Epoch"):
    in_train_correct, in_train_loss, in_train_total = train(train_loader)

    in_eval_correct, in_eval_loss, in_eval_total = evaluate(eval_loader)

    scheduler.step()

    train_accuracy.append(in_train_correct / in_train_total)
    train_loss.append(in_train_loss / len(train_loader))
    eval_accuracy.append(in_eval_correct / in_eval_total)
    eval_loss.append(in_eval_loss / len(eval_loader))
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(6, 4), dpi=100)

fig.tight_layout()

ax1.grid(True, axis="y", ls="--")
ax1.plot(train_accuracy, label="Test Accuracy")
ax1.plot(eval_accuracy, label="Evaluation Accuracy")
ax1.legend(frameon=False)

ax2.grid(True, axis="y", ls="--")
ax2.plot(train_loss, label="Training Loss")
ax2.plot(eval_loss, label="Evaluation Loss")
ax2.legend(frameon=False)

fig.show()
targets = torch.tensor([]).to(device)
predictions = torch.tensor([]).to(device)

with torch.no_grad():
    model.eval()
    for image, label in eval_loader:
        image = autograd.Variable(image.view(-1, 1, 28, 28)).to(device)
        label = autograd.Variable(label).to(device)

        output = model(image)

        targets = torch.cat((targets, label), dim=0)
        predictions = torch.cat((predictions, output), dim=0)

targets = np.array(targets.type(torch.LongTensor))

predictions = predictions.cpu()
cm = metrics.confusion_matrix(targets, predictions.argmax(dim=1)) #.to("cpu")???

plt.figure(figsize=(10, 8.5))

plt.imshow(np.log2(cm + 1), cmap="Reds")
plt.colorbar()
plt.tick_params(size=5, color="white")
plt.xticks(np.arange(0, len(values)), np.arange(0, len(values)))
plt.yticks(np.arange(0, len(values)), np.arange(0, len(values)))

threshold = cm.max() / 2

for index in range(len(values)):
    for jndex in range(len(values)):
        if cm[index, jndex] > threshold:
            color = "w"
        else:
            color = "k"

        plt.text(jndex, index,
                 int(cm[index, jndex]),
                 horizontalalignment="center", color=color)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()
predictions = np.array(torch.max(predictions, 1)[1])
misclassified = np.unique(targets == predictions, return_counts=True)[1][0]

print(f"Error rate: {misclassified / len(predictions) * 100:.2f}%")
submission = pd.read_csv("../input/digit-recognizer/test.csv", dtype=np.uint8).values / 255
submission = torch.from_numpy(submission).type(torch.FloatTensor)
submission = data.DataLoader(submission, batch_size=batch_size)
with torch.no_grad():
    predictions = torch.tensor([]).to(device)

    for image in submission:
        image = autograd.Variable(image.view(-1, 1, 28, 28)).to(device)
        output = model(image)

        predictions = torch.cat((predictions, output), dim=0)
submission = []
for index, prediction in enumerate(predictions.argmax(dim=1)):
    submission.append([index + 1, prediction.cpu().numpy()])
df = pd.DataFrame(submission, columns=["ImageId", "Label"])
df.to_csv("submission.csv", index=False)
print("Submission File Complete!")