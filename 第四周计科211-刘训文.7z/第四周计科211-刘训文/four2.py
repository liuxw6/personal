import cv2
import numpy as np
img = cv2.imread('gun.jpg')
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)#图片转HSV格式便于颜色识别
low = np.array([0, 153, 28])#设低阈值
up = np.array([80, 232, 197])#设高阈值
mask = cv2.inRange(hsv, low, up)#创建蒙版
img1 = cv2.bitwise_and(img, img, mask=mask)#位运算使得所需部分外为黑色
gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)#将图像格式转为灰度
ret, thresh = cv2.threshold(gray, 0, 255,cv2.THRESH_OTSU)#自适应二值化处理
contours, hie = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)#寻找图像所有轮廓

area = []  # 创建一个空列表
for i in range(len(contours)):
    area.append(cv2.contourArea(contours[i]))  # 将轮廓面积逐个加入空列表
max = np.argmax(np.array(area))  # 找到最大面积的轮廓的下标
cnt = contours[max]#将最大轮廓存入cnt

x, y, w, h = cv2.boundingRect(cnt)#根据最大轮廓找到贴合的直矩形并返回左上角点、宽高
img = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 5)#绘制矩形
center=(int(x+w/2),int(y+h/2))#计算中心点
print('长：', h, '宽：', w,'中心点：',center)#输出矩形参数

(x, y), radius = cv2.minEnclosingCircle(cnt)#根据最大轮廓找到最小外接圆并返回圆心、半径
center = (int(x), int(y))
radius = int(radius)
img = cv2.circle(img, center, radius, (0, 255, 0), 2)#对圆心、半径取整绘制外接圆
print("圆心：",(int(x), int(y)),"半径：",radius)#输出外接圆参数

cv2.namedWindow('shibie', cv2.WINDOW_NORMAL)
cv2.imshow('shibie', img)#展示识别效果
cv2.waitKey(0)
cv2.destroyAllWindows()

# 获取四个极点
left = tuple(cnt[cnt[:, :, 0].argmin()][0])
right = tuple(cnt[cnt[:, :, 0].argmax()][0])
top = tuple(cnt[cnt[:, :, 1].argmin()][0])
bottom = tuple(cnt[cnt[:, :, 1].argmax()][0])
print('极点为：')
print(left)
print(right)
print(top)
print(bottom)
