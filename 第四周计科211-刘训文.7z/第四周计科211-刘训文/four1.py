import cv2
import numpy as np
cv2.namedWindow('hh',cv2.WINDOW_NORMAL)
img = cv2.imread('label.jpg')
img_Gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)#将img2变为灰度图像为做二值化作准备
img2=cv2.adaptiveThreshold(img_Gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,151,20)#用自适应阈值二值化图片
cv2.imshow('hh',img2)
k= cv2.waitKey(0)
cv2.destroyAllWindows()

