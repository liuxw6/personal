import numpy as np
import cv2
def nothing(x):
    pass
def img_blending(wdName, trackBarName, image1, image2, ):
    x= (100 - cv2.getTrackbarPos(trackBarName, wdName)) / 100  # 获取滑动条的值并转换成小数
    y= 1 - x
    return cv2.addWeighted(image1,x, image2, y, 0)  # #混合过渡
img1=cv2.imread("football.png")
img2=cv2.imread("logo.png")
img4=cv2.imread("red block.png")
img4=cv2.resize(img4,(750,467))
print('img1图片信息：',end=' ')
print(img1.shape,end=' ')#输出行列、通道
print(img1.size,end=' ')#输出像素数
print(img1.dtype)#输出图像数据类型
print('img2图片信息：',end=' ')
print(img2.shape,end=' ')#输出行列、通道
print(img2.size,end=' ')#输出像素数
print(img2.dtype)#输出图像数据类型
rows,cols,channels=img2.shape#记录img2行列
roi = img1[0:rows, 0:cols]#从img1左上角复制一块与img2大小相同的roi区域
img2_Gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)#将img2变为灰度图像为做蒙版作准备
ret, mask = cv2.threshold(img2_Gray, 175, 255, cv2.THRESH_BINARY)
#ret占返回值不使用，用mask获取蒙版，以175作为分类阈值，255为阈值上限，使得蒙版为黑白两色
mask_inv = cv2.bitwise_not(mask)#对蒙版取反
img1_bg = cv2.bitwise_and(roi,roi,mask=mask)
img2_fg = cv2.bitwise_and(img2,img2,mask=mask_inv)
#以上两句让roi区域和img2所需部分外的部分变黑（像素值为0），使得以下的cv2.add（）函数能按需拼接roi区域和img2所需部分
dst = cv2.add(img1_bg,img2_fg)
img1[0:rows, 0:cols ] = dst#将拼接好的部分放到img1左上角
img3=cv2.imread("football.png")#获得一份原始图像使得足球区域能被复制
football = img3[392:457,459:538]
img1[387:462,454:543] = (0, 0, 255)
img1[392:457,459:538]=football#用红色框框起足球
cv2.namedWindow('image')#创建窗口
cv2.createTrackbar('change','image',0,100,nothing)#创建滑动条
while 1:
    cv2.imshow('image', img_blending('image','change' , img1, img4))#混合过渡img1和img4
    k = cv2.waitKey(1) & 0xFF  # 按 “ESC” 退出
    if k == 27:
        break
cv2.destroyAllWindows()

