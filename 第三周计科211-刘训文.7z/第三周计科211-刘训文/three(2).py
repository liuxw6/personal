import cv2
import numpy as np
img = cv2.imread('red block.png')
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)  # 将图片转换到HSV
lower_red = np.array([50, 50, 30])  # 设定红色的阈值，图像中低于这个值的，图像变为0
upper_red = np.array([255, 255, 200])  # 设定红色的阈值，图像中高于这个值的，图像变为0
# 在这两个值的中间值的都为255
mask = cv2.inRange(hsv, lower_red, upper_red)#按阈值生成蒙版
res = cv2.bitwise_and(img, img, mask=mask)# 对原图像和蒙版进行位运算，使得画面只留下长方形
#二值化处理
rows = img.shape[0]#记录行
cols = img.shape[1]#记录列
M = cv2.getRotationMatrix2D((cols/2, rows/2), -20, 1)#构建旋转矩阵，等比例顺时针旋转20度摆正长方形
cv2.namedWindow('dst', cv2.WINDOW_NORMAL)#创建窗口
dst = cv2.warpAffine(res, M, (cols,rows))#仿射变换，将长方形旋转以后再输出
cv2.imshow('dst', dst)
k= cv2.waitKey(0)

cv2.destroyAllWindows()