import cv2
import numpy as np
from matplotlib import pyplot as plt
img = cv2.imread('girl.png',0)
equ = cv2.equalizeHist(img)#直方图均衡化
cv2.imwrite('equ.png',equ)
img2 = cv2.imread('equ.png')
hsv = cv2.cvtColor(img2,cv2.COLOR_BGR2HSV)#图片转hsv格式
hist = cv2.calcHist([hsv], [0, 1], None, [180, 256], [0, 180, 0, 256])#计算新直方图
plt.imshow(hist,interpolation = 'nearest')#绘制直方图
plt.show()#展示直方图
cv2.waitKey(0)
cv2.destroyAllWindows()
