import numpy as np
import cv2
from matplotlib import pyplot as plt
img = cv2.imread('house.jpg',0)
dft = cv2.dft(np.float32(img),flags = cv2.DFT_COMPLEX_OUTPUT)#傅里叶变换
dft_shift = np.fft.fftshift(dft)#将低频移动到中心
rows, cols = img.shape#计算原图宽高
crow,ccol = int(rows/2 ), int(cols/2)#得出图像中心
dft_shift[crow-8:crow+8, ccol-128:ccol-7] = 1
dft_shift[crow-8:crow+8, ccol+7:ccol+128] = 1
#因为竖条纹为噪声，低频移动后横向分布在中心左右，保留中心的情况下使其左右两侧变为1
f_ishift = np.fft.ifftshift(dft_shift)#将低频返回原处
idft=cv2.idft(f_ishift)#傅里叶反变换
img_back = cv2.magnitude(idft[:,:,0],idft[:,:,1])#计算矩阵加和平方根，使得图片正常显示
plt.imshow(img_back, cmap = 'gray')
plt.show()#展现处理后图片
cv2.waitKey(0)
cv2.destroyAllWindows()

