import cv2
import numpy as np
import math
img_rgb = cv2.imread('checkerboard .png')
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)#转成灰度图

img = cv2.imread('checkerboard .png')
gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray,50,200,apertureSize = 3)#轮廓检测
lines = cv2.HoughLines(edges,1,np.pi/180,200)#检测直线
for i in range(0,len(lines)):#遍历每条直线
    rho, theta = lines[i][0][0], lines[i][0][1]
    a = np.cos(theta)
    b = np.sin(theta)
    x0 = a*rho
    y0 = b*rho
    x1 = int(x0 + 1000*(-b))
    y1 = int(y0 + 1000*(a))
    x2 = int(x0 - 1000*(-b))
    y2 = int(y0 - 1000*(a))
    cv2.line(img_rgb,(x1,y1),(x2,y2),(0,0,0),2)#经过一系列计算将每条直线画出

template1 = cv2.imread('black.png',0)#引入黑棋模板
template2 = cv2.imread('white.png',0)#引入白棋模板
w1, h1 = template1.shape[::-1]
w2, h2 = template2.shape[::-1]#得出模板宽高
res1 = cv2.matchTemplate(img_gray,template1,cv2.TM_CCOEFF_NORMED)
res2 = cv2.matchTemplate(img_gray,template2,cv2.TM_CCOEFF_NORMED)#进行模板匹配
threshold = 0.8#设定阈值
loc1 = np.where( res1 >= threshold)
loc2 = np.where( res2 >= threshold)#返回符合条件的矩阵
max1=0
max2=0

for pt in zip(*loc1[::-1]):#遍历每个黑棋
    lastX = pt[0]+w1/2.0
    lastY = pt[1]+h1/2.0#获取比较棋子a坐标
    for tp in zip(*loc1[::-1]):
        newX = tp[0]+w1/2.0
        newY = tp[1]+h1/2.0#获取比较棋子b坐标
        minus1 = lastX - newX
        minus2 = lastY - newY# 得到差值
        part1 = math.pow(minus1, 2)
        part2 = math.pow(minus2, 2)  # 求平方
        dis = int(math.sqrt(part1 + part2))  # 开根号求两圆心距离
        if dis > max1:#dis比max1大就更新max1并记录此时的a、b棋子坐标且取整
            max1 = dis
            point1 = (int(newX), int(newY))
            point2 = (int(lastX), int(lastY))
cv2.line(img_rgb,point1,point2,(0,0,255),3)#对最远两黑棋连线
#下面是白棋的连线处理，与黑棋仅有变量名不一致
for pt in zip(*loc2[::-1]):
    lastX = pt[0]+w2/2.0
    lastY = pt[1]+h2/2.0
    for tp in zip(*loc2[::-1]):
        newX = tp[0]+w2/2.0
        newY = tp[1]+h2/2.0
        minus1 = lastX - newX
        minus2 = lastY - newY
        part1 = math.pow(minus1, 2)
        part2 = math.pow(minus2, 2)
        dis = int(math.sqrt(part1 + part2))
        if dis > max2:
            max2 = dis
            point1 = (int(newX), int(newY))
            point2 = (int(lastX), int(lastY))
cv2.line(img_rgb,point1,point2,(0,255,0),3)

print("黑棋最大距离为：",max1)
print("白棋最大距离为：",max2)#输出黑白棋最大距离
cv2.imshow('xiaoguo',img_rgb)
cv2.waitKey(0)
cv2.destroyAllWindows()


